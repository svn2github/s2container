package examples.tx;

public interface Hoge {

	public void foo();
}
