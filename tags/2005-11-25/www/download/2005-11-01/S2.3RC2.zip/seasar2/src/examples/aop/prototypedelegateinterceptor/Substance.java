package examples.aop.prototypedelegateinterceptor;

public class Substance implements IBase{
	public void run() {
		System.out.println(this);
	}
}
