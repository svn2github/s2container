package examples.aop.delegateinterceptor;

public abstract class Dummy implements IBase {
}

