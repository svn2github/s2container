package examples.aop.delegateinterceptor;

public class Substance implements IBase{
	public void run() {
		System.out.println("substance");
	}
}
