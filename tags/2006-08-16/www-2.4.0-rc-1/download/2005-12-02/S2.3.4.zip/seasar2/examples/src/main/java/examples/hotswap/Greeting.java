package examples.hotswap;

public interface Greeting {

    String greet();
}