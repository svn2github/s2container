package examples.aop.delegateinterceptor;

public interface IBase {
	public abstract void run();
}