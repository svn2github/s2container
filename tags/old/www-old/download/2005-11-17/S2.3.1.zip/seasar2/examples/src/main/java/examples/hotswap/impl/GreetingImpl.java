package examples.hotswap.impl;

import examples.hotswap.Greeting;

public class GreetingImpl implements Greeting {

    public String greet() {
        return "Hello2";
    }
}