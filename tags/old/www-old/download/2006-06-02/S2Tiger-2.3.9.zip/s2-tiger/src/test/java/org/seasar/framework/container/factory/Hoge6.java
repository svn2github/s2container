package org.seasar.framework.container.factory;

import org.seasar.framework.container.annotation.tiger.InitMethod;

public class Hoge6 {

    @InitMethod
    public void init(String s) {
    }
}
