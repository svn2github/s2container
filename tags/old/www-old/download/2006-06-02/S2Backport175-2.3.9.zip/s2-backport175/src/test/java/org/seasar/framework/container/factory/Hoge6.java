package org.seasar.framework.container.factory;

public class Hoge6 {

    /**
     * @org.seasar.framework.container.annotation.backport175.InitMethod
     */
    public void init(String s) {
    }
}
