package org.seasar.framework.container.factory;

public class Hoge4 {

    /**
     * @return
     * @org.seasar.framework.container.annotation.backport175.Aspect(
     *  "aop.traceInterceptor")
     */
    public String getAaa() {
        return null;
    }

    public String getAaa(String aaa) {
        return aaa;
    }
}
