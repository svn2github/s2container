package org.seasar.framework.container.factory;

public class Hoge5 {

    /**
     * @org.seasar.framework.container.annotation.backport175.InitMethod
     */
    public void init() {
    }
}
