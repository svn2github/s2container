package org.seasar.framework.container.factory;

public interface IHoge7 {
    void execute();
}
