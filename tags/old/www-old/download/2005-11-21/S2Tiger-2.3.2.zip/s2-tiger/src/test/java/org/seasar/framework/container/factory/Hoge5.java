package org.seasar.framework.container.factory;

import org.seasar.framework.container.annotation.tiger.InitMethod;

public class Hoge5 {

	@InitMethod
    public void init() {
    }
}
