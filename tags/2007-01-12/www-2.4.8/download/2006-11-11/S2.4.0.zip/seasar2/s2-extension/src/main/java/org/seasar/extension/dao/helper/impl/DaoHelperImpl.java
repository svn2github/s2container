/*
 * Copyright 2004-2006 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.extension.dao.helper.impl;

import java.lang.reflect.Method;

import org.seasar.extension.dao.DaoConstants;
import org.seasar.extension.dao.DaoNotFoundRuntimeException;
import org.seasar.extension.dao.helper.DaoHelper;
import org.seasar.framework.convention.NamingConvention;
import org.seasar.framework.exception.EmptyRuntimeException;
import org.seasar.framework.util.ResourceUtil;
import org.seasar.framework.util.StringUtil;
import org.seasar.framework.util.TextUtil;

/**
 * @author higa
 * 
 */
public class DaoHelperImpl implements DaoHelper {

    private NamingConvention namingConvention;

    /**
     * @return Returns the namingConvention.
     */
    public NamingConvention getNamingConvention() {
        return namingConvention;
    }

    /**
     * @param namingConvention
     *            The namingConvention to set.
     */
    public void setNamingConvention(NamingConvention namingConvention) {
        this.namingConvention = namingConvention;
    }

    public Class getDaoInterface(Class clazz) {
        if (clazz.isInterface()) {
            return clazz;
        }
        for (Class target = clazz; target != Object.class; target = target
                .getSuperclass()) {
            Class[] interfaces = target.getInterfaces();
            for (int i = 0; i < interfaces.length; ++i) {
                Class intf = interfaces[i];
                if (intf.getName().endsWith(namingConvention.getDaoSuffix())) {
                    return intf;
                }
            }
        }
        throw new DaoNotFoundRuntimeException(clazz);
    }

    public String getDataSourceName(Class daoClass) {
        Class intf = getDaoInterface(daoClass);
        String className = intf.getName();
        String key = "." + namingConvention.getDaoPackageName() + ".";
        int index = className.lastIndexOf(key);
        if (index < 0) {
            throw new IllegalArgumentException(daoClass.getName());
        }
        int index2 = className.lastIndexOf('.');
        if (index + key.length() - 1 == index2) {
            return null;
        }
        return className.substring(index + key.length(), index2);
    }

    public String getSqlBySqlFile(Class daoClass, Method method, String suffix) {
        String base = daoClass.getName().replace('.', '/') + "_"
                + method.getName();
        String dbmsPath = base
                + (StringUtil.isEmpty(suffix) ? "" : "_" + suffix)
                + DaoConstants.SQL_EXTENSION;
        String standardPath = base + DaoConstants.SQL_EXTENSION;
        if (ResourceUtil.isExist(dbmsPath)) {
            return TextUtil.readUTF8(dbmsPath);
        } else if (ResourceUtil.isExist(standardPath)) {
            return TextUtil.readUTF8(standardPath);
        }
        return null;
    }

    public String fromRdbmsToJavaName(String name) {
        if (name == null) {
            throw new EmptyRuntimeException("name");
        }
        name = name.toLowerCase();
        String[] array = StringUtil.split(name, "_");
        if (array.length == 1) {
            return name;
        }
        StringBuffer buf = new StringBuffer(30);
        buf.append(array[0]);
        for (int i = 1; i < array.length; ++i) {
            buf.append(StringUtil.capitalize(array[i]));
        }
        return buf.toString();
    }

    public String fromJavaToRdbmsName(String name) {
        if (name == null) {
            throw new EmptyRuntimeException("name");
        }
        if (name.length() == 1) {
            return name.toUpperCase();
        }
        StringBuffer buf = new StringBuffer(30);
        int pos = 0;
        for (int i = 1; i < name.length(); ++i) {
            if (Character.isUpperCase(name.charAt(i))) {
                if (buf.length() != 0) {
                    buf.append('_');
                }
                buf.append(name.substring(pos, i).toUpperCase());
                pos = i;
            }
        }
        if (buf.length() != 0) {
            buf.append('_');
        }
        buf.append(name.substring(pos, name.length()).toUpperCase());
        return buf.toString();
    }
}