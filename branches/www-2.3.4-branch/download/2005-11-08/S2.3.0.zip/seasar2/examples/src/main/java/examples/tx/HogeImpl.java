package examples.tx;

public class HogeImpl implements Hoge {

	public void foo() {
		System.out.println("foo");
	}

}
