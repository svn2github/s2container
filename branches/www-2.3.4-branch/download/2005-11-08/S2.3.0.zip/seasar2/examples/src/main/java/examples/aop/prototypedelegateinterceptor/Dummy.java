package examples.aop.prototypedelegateinterceptor;

public abstract class Dummy implements IBase {
}

