package examples.aop.syncinterceptor;

public interface Count {

	public void add();
	
	public int get();
}
