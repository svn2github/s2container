package examples.aop.mockinterceptor;

public interface Hello {

	public String greeting();
	
	public String echo(String str);
	
}
