package examples.unit;

public interface EmployeeDao {

	public Employee getEmployee(int empno);
}
