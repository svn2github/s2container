package examples.di;

public interface Greeting {

    String greet();
}