package examples.di;

public interface GreetingClient {

    void execute();
}