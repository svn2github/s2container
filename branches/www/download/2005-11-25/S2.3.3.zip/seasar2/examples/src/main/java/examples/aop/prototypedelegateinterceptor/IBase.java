package examples.aop.prototypedelegateinterceptor;

public interface IBase {
	public abstract void run();
}